import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from 'path'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: "10.10.20.60", 
    port: 3004,  
    proxy: {
      '/api': {
        target: 'https://rnj64vmh-9050.inc1.devtunnels.ms/api/v1',
        changeOrigin: true,
        secure: false,
        rewrite: (path) => path.replace(/^\/api/, ''),
        headers: {
          'bypass-tunnel-reminder': 'true'
        }
      },
      '/socket.io': {
        target: 'https://rnj64vmh-9050.inc1.devtunnels.ms',
        changeOrigin: true,
        secure: false,
        ws: true,
        headers: {
          'bypass-tunnel-reminder': 'true'
        }
      }
    }
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
})
